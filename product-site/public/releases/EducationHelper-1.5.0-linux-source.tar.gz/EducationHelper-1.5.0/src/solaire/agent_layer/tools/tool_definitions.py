"""Unified tool schema definitions — extracted from registry.py."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, replace
from typing import Any

from solaire.agent_layer.models import InvocationContext, ToolResult, ToolRisk
from solaire.agent_layer.tools import (
    analysis_tools,
    bank_tools,
    doc_tools,
    exam_tools,
    file_tools,
    graph_tools,
    memory_tools,
    pipeline_tools,
    session_tools,
    teacher_tools,
    web_tools,
)

ToolHandler = Callable[[InvocationContext, dict[str, Any]], ToolResult]


@dataclass
class RegisteredTool:
    name: str
    description: str
    parameters_schema: dict[str, Any]
    handler: ToolHandler
    risk: ToolRisk = ToolRisk.WRITE
    ui_label: str | None = None
    requires_confirmation_override: bool | None = None
    allegro_auto_add: bool = False
    vivace_fast_review: bool = False
    action_label: str | None = None


def _fn(
    name: str,
    description: str,
    parameters: dict[str, Any],
    handler: ToolHandler,
    *,
    risk: ToolRisk = ToolRisk.WRITE,
    ui_label: str | None = None,
    requires_confirmation_override: bool | None = None,
    allegro_auto_add: bool = False,
    vivace_fast_review: bool = False,
    action_label: str | None = None,
) -> RegisteredTool:
    return RegisteredTool(
        name=name,
        description=description,
        parameters_schema=parameters,
        handler=handler,
        risk=risk,
        ui_label=ui_label,
        requires_confirmation_override=requires_confirmation_override,
        allegro_auto_add=allegro_auto_add,
        vivace_fast_review=vivace_fast_review,
        action_label=action_label,
    )


def _analysis(
    name: str,
    description: str,
    parameters: dict[str, Any],
    *,
    risk: ToolRisk = ToolRisk.WRITE,
    ui_label: str | None = None,
    allegro_auto_add: bool = False,
    vivace_fast_review: bool = False,
    action_label: str | None = None,
) -> RegisteredTool:
    return _fn(
        name,
        description,
        parameters,
        lambda ctx, args: analysis_tools.run_analysis_tool(ctx, name, args),
        risk=risk,
        ui_label=ui_label,
        allegro_auto_add=allegro_auto_add,
        vivace_fast_review=vivace_fast_review,
        action_label=action_label,
    )


_RAW_TOOLS: list[RegisteredTool] = [
    _analysis(
        "analysis.list_datasets",
        "列出当前内容库中可用的考试成绩数据集（考试与批次）。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        risk=ToolRisk.READ,
        ui_label="正在读取考试数据列表…",
    ),
    _analysis(
        "analysis.list_builtins",
        "列出可用的内置分析流水线标识。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        risk=ToolRisk.READ,
        ui_label="正在读取可用分析类型…",
    ),
    _analysis(
        "analysis.run_builtin",
        "运行一条内置分析流水线并创建作业；完成后可用 analysis.get_job 取结果。",
        {
            "type": "object",
            "properties": {
                "builtin_id": {"type": "string"},
                "exam_id": {"type": "string"},
                "batch_id": {"type": "string"},
                "recompute": {"type": "boolean"},
                "request_id": {"type": "string"},
            },
            "required": ["builtin_id", "exam_id", "batch_id"],
            "additionalProperties": False,
        },
        ui_label="正在启动学情分析…",
        allegro_auto_add=True,
    ),
    _analysis(
        "analysis.save_script",
        "保存或更新一条分析脚本（执行受沙箱限制）。",
        {
            "type": "object",
            "properties": {
                "script_id": {"type": "string"},
                "name": {"type": "string"},
                "language": {"type": "string"},
                "code": {"type": "string"},
            },
            "required": ["name", "code"],
            "additionalProperties": False,
        },
        ui_label="正在保存分析脚本…",
    ),
    _analysis(
        "analysis.run_script",
        "在沙箱中运行已保存的分析脚本。",
        {
            "type": "object",
            "properties": {
                "script_id": {"type": "string"},
                "exam_id": {"type": "string"},
                "batch_id": {"type": "string"},
                "request_id": {"type": "string"},
            },
            "required": ["script_id", "exam_id", "batch_id"],
            "additionalProperties": False,
        },
        ui_label="正在运行分析脚本…",
        allegro_auto_add=True,
    ),
    _analysis(
        "analysis.get_job",
        "按作业标识获取分析作业状态与输出。",
        {
            "type": "object",
            "properties": {"job_id": {"type": "string"}, "include_output": {"type": "boolean"}},
            "required": ["job_id"],
            "additionalProperties": False,
        },
        risk=ToolRisk.READ,
        ui_label="正在查询分析进度…",
    ),
    _fn(
        "analysis.create_remediation_draft",
        "根据某次考试成绩批次的学情诊断结果，生成一份可编辑的补练卷组卷草稿。",
        {
            "type": "object",
            "properties": {
                "exam_id": {"type": "string", "description": "源考试标识，如 期中/数学"},
                "batch_id": {"type": "string", "description": "成绩批次 id"},
                "weak_limit": {"type": "integer", "description": "最多参考的薄弱知识点数量，默认 5"},
                "practice_per_node": {"type": "integer", "description": "每个知识点最多取题数，默认 4"},
                "exclude_source_exam_questions": {
                    "type": "boolean",
                    "description": "是否排除原考试已用题，默认 true",
                },
                "template_ref": {"type": "string", "description": "可选，覆盖源考试模板 id"},
                "template_path": {"type": "string", "description": "可选，覆盖源考试模板路径"},
                "export_label": {"type": "string", "description": "可选，新草稿试卷说明"},
            },
            "required": ["exam_id", "batch_id"],
            "additionalProperties": False,
        },
        analysis_tools.tool_create_remediation_draft,
        ui_label="正在生成补练卷草稿…",
    ),
    _fn(
        "exam.list_templates",
        "列出内容目录中的试卷模板（路径、小节与版式信息）。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        exam_tools.tool_list_templates,
        risk=ToolRisk.READ,
        ui_label="正在读取试卷模板…",
    ),
    _fn(
        "exam.get_template_preview",
        "读取指定模板 YAML 的结构化预览。",
        {
            "type": "object",
            "properties": {"template_path": {"type": "string"}},
            "required": ["template_path"],
            "additionalProperties": False,
        },
        exam_tools.tool_template_preview,
        risk=ToolRisk.READ,
        ui_label="正在预览模板结构…",
    ),
    _fn(
        "exam.validate_paper",
        "校验当前选题与试卷模板是否匹配（卷面结构、题目是否存在等），并写入临时校验用配置。"
        "默认不做试卷版式编译；将 include_latex_check 设为 true 时，会额外试跑与导出相同的版式编译以提前发现版式错误。"
        "返回中的 math_warnings 为题干内数学公式定界符等静态提示，不能替代完整导出。",
        {
            "type": "object",
            "properties": {
                "template_ref": {"type": "string"},
                "template_path": {"type": "string"},
                "include_latex_check": {
                    "type": "boolean",
                    "description": "为 true 时试跑版式编译（较慢，需本机已安装 latexmk）",
                },
                "include_math_static": {
                    "type": "boolean",
                    "description": "为 false 时跳过题干内数学公式定界符静态检查（默认 true）",
                },
                "selected_items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "section_id": {"type": "string"},
                            "question_ids": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["section_id", "question_ids"],
                    },
                },
            },
            "required": ["template_ref", "template_path", "selected_items"],
            "additionalProperties": False,
        },
        exam_tools.tool_validate_paper,
        ui_label="正在校验组卷…",
    ),
    _fn(
        "exam.export_paper",
        "校验通过后导出学生版与教师版 PDF（高影响操作，需确认）。",
        {
            "type": "object",
            "properties": {
                "template_ref": {"type": "string"},
                "template_path": {"type": "string"},
                "selected_items": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "section_id": {"type": "string"},
                            "question_ids": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["section_id", "question_ids"],
                    },
                },
                "export_label": {"type": "string"},
                "subject": {"type": "string"},
                "metadata_title": {"type": "string"},
                "allow_replace_conflicting_export": {
                    "type": "boolean",
                    "description": "当已有其他目录占用相同试卷说明与学科时，是否仍允许导出（请谨慎）",
                },
            },
            "required": ["template_ref", "template_path", "selected_items", "export_label", "subject"],
            "additionalProperties": False,
        },
        exam_tools.tool_export_paper,
        risk=ToolRisk.DESTRUCTIVE,
        ui_label="正在准备导出试卷…",
        vivace_fast_review=True,
    ),
    _fn(
        "exam.publish_online_paper",
        "发布已生成的试卷到指定班级，可选择线上答题、图片人工批改或图片 OCR+AI 批改提交方式。",
        {
            "type": "object",
            "properties": {
                "paper_id": {"type": "string"},
                "paper_title": {"type": "string", "description": "试卷标题或标题中的关键词；当用户没有给出 paper_id 时使用。"},
                "exam_id": {"type": "string", "description": "考试目录标识，例如 midterm/Math；当用户按考试名称发布时使用。"},
                "class_ids": {"type": "array", "items": {"type": "string"}},
                "class_names": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "班级名称或名称关键词；当用户没有给出 class_ids 时使用。",
                },
                "title": {"type": "string"},
                "subject": {"type": "string", "description": "教师设置多个学科时必填，必须选择本次发布所属学科。"},
                "description": {"type": "string"},
                "start_at": {"type": "string"},
                "end_at": {"type": "string"},
                "time_limit_minutes": {"type": "integer", "minimum": 0, "maximum": 1440},
                "submission_mode": {
                    "type": "string",
                    "enum": ["online", "image_manual", "image_ai"],
                    "description": "online 为网页答题，image_manual 为图片提交人工批改，image_ai 为图片提交后 AI 建议批改并由教师审核。",
                },
                "max_screen_switches": {"type": "integer", "minimum": 0, "maximum": 999},
                "show_results_immediately": {"type": "boolean"},
            },
            "additionalProperties": False,
        },
        exam_tools.tool_publish_online_paper,
        ui_label="正在发布线上试卷...",
        action_label="发布线上试卷",
    ),
    _fn(
        "exam.ai_grade_submission",
        "为某次学生提交生成 AI 批改建议；建议不会直接改分，教师仍需审核确认。",
        {
            "type": "object",
            "properties": {
                "paper_id": {"type": "string"},
                "attempt_id": {"type": "string"},
                "student_query": {
                    "type": "string",
                    "description": "学生学号、登录账号或姓名；未提供 attempt_id 时使用。",
                },
                "question_ids": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["paper_id"],
            "additionalProperties": False,
        },
        exam_tools.tool_ai_grade_submission,
        ui_label="正在生成 AI 批改建议...",
        action_label="生成 AI 批改建议",
    ),
    _fn(
        "bank.search_items",
        "在题库中按关键词或题型筛选题目，返回完整标识与内容摘要。",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "关键词，可匹配题干摘要或标识；留空则仅按题型筛选"},
                "question_type": {
                    "type": "string",
                    "description": "题型：single_choice / multiple_choice / fill / judge / short_answer / reasoning / essay；旧 choice 可兼容读取；可留空",
                },
                "max_hits": {"type": "integer", "description": "最多返回条数，默认 30，最大 80"},
            },
            "additionalProperties": False,
        },
        bank_tools.tool_bank_search_items,
        risk=ToolRisk.READ,
        ui_label="正在检索题库…",
    ),
    _fn(
        "bank.export_items",
        "将已检索并选定的部分题目按题型和标识梳理为 EducationHelper YAML 文件，并在对话中提供直接下载按钮。",
        {
            "type": "object",
            "properties": {
                "qualified_ids": {"type": "array", "items": {"type": "string"}, "minItems": 1, "maxItems": 300},
                "title": {"type": "string"},
            },
            "required": ["qualified_ids"],
            "additionalProperties": False,
        },
        bank_tools.tool_bank_export_items,
        risk=ToolRisk.READ,
        ui_label="正在梳理并导出题目…",
    ),
    _fn(
        "bank.get_item",
        "读取教师个人题库中一道题目的完整内容与结构。",
        {
            "type": "object",
            "properties": {"qualified_id": {"type": "string", "description": "题目完整标识"}},
            "required": ["qualified_id"],
            "additionalProperties": False,
        },
        bank_tools.tool_bank_get_item,
        risk=ToolRisk.READ,
        ui_label="正在打开题目详情…",
    ),
    _fn(
        "bank.update_item",
        "修改已有独立题目的题干、答案、解析或选项（写入操作，可能需确认）。保存后会返回 format_warnings；若 format_ok=false，必须继续修正。",
        {
            "type": "object",
            "properties": {
                "qualified_id": {"type": "string"},
                "content": {"type": "string"},
                "answer": {"type": "string"},
                "analysis": {"type": "string"},
                "options": {"type": "string", "description": "选择题选项，JSON 对象字符串，如 {\"A\":\"...\",\"B\":\"...\"}"},
                "metadata": {"type": "string", "description": "附加说明字段的 JSON 字符串"},
            },
            "required": ["qualified_id"],
            "additionalProperties": False,
        },
        bank_tools.tool_bank_update_item,
        ui_label="正在保存题目修改…",
    ),
    _fn(
        "bank.create_item",
        "在教师个人题库中新建一道题目。由模型原创时 source_kind=AI生成；依据教师文件整理导入时必须用 AI辅助导入。",
        {
            "type": "object",
            "properties": {
                "subject": {
                    "type": "string",
                    "description": "题目所属学科，未提供时使用通用",
                },
                "question_id": {"type": "string"},
                "question_type": {"type": "string"},
                "content": {"type": "string"},
                "answer": {"type": "string"},
                "analysis": {"type": "string"},
                "options": {"type": "string", "description": "选择题必填，JSON 对象字符串"},
                "metadata": {"type": "string", "description": "JSON 对象字符串"},
                "source_kind": {"type": "string", "enum": ["AI生成", "AI辅助导入"]},
            },
            "required": ["question_id", "question_type", "content", "answer"],
            "additionalProperties": False,
        },
        bank_tools.tool_bank_create_item,
        ui_label="正在新建题目…",
        allegro_auto_add=True,
    ),
    _fn(
        "graph.list_graphs",
        "列出所有科目图谱（slug、显示名、节点数）。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        graph_tools.tool_list_graphs,
        risk=ToolRisk.READ,
        ui_label="正在读取图谱列表…",
    ),
    _fn(
        "graph.create_graph",
        "创建新科目图谱。",
        {
            "type": "object",
            "properties": {
                "display_name": {"type": "string", "description": "图谱显示名称（如：数学）"},
                "slug": {"type": "string", "description": "内部标识（可选，留空自动生成）"},
            },
            "required": ["display_name"],
            "additionalProperties": False,
        },
        graph_tools.tool_create_graph,
        ui_label="正在创建图谱…",
    ),
    _fn(
        "graph.delete_graph",
        "删除科目图谱（不可逆，请谨慎）。",
        {
            "type": "object",
            "properties": {"slug": {"type": "string", "description": "图谱内部标识"}},
            "required": ["slug"],
            "additionalProperties": False,
        },
        graph_tools.tool_delete_graph,
        risk=ToolRisk.DESTRUCTIVE,
        ui_label="正在删除图谱…",
        vivace_fast_review=True,
    ),
    _fn(
        "graph.list_nodes",
        "列出知识图谱节点，可按类型筛选；graph 参数指定科目图谱 slug（留空则全部）。",
        {
            "type": "object",
            "properties": {
                "node_kind": {"type": "string", "description": "concept / skill / causal，可留空"},
                "graph": {"type": "string", "description": "科目图谱 slug，可留空"},
            },
            "additionalProperties": False,
        },
        graph_tools.tool_list_nodes,
        risk=ToolRisk.READ,
        ui_label="正在读取知识要点…",
    ),
    _fn(
        "graph.search_nodes",
        "按关键词在知识要点名称、别名与说明中检索，返回有限条结果（避免一次加载全量图谱）。",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "关键词，可多个词（需同时匹配）"},
                "node_kind": {"type": "string", "description": "concept / skill / causal，可留空"},
                "max_hits": {"type": "integer", "description": "最多返回条数，默认 30，最大 200"},
                "graph": {"type": "string", "description": "科目图谱 slug，可留空"},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
        graph_tools.tool_search_nodes,
        risk=ToolRisk.READ,
        ui_label="正在搜索知识要点…",
    ),
    _fn(
        "graph.create_node",
        "创建图谱节点；无 id 时需 parent_node_id 与 canonical_name 以自动生成标识。graph 参数指定目标科目图谱。",
        {
            "type": "object",
            "properties": {
                "id": {"type": "string"},
                "parent_node_id": {"type": "string"},
                "canonical_name": {"type": "string"},
                "node_kind": {"type": "string"},
                "aliases": {"type": "array", "items": {"type": "string"}},
                "subject": {"type": "string"},
                "level": {"type": "string"},
                "description": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "primary_parent_id": {"type": "string", "description": "思维导图主父节点 ID"},
                "graph": {"type": "string", "description": "科目图谱 slug"},
            },
            "required": ["canonical_name"],
            "additionalProperties": False,
        },
        graph_tools.tool_create_node,
        ui_label="正在创建知识要点…",
        allegro_auto_add=True,
    ),
    _fn(
        "graph.batch_create_nodes",
        "批量创建知识要点节点；每项规则同 graph.create_node（可混用自动生成 id 与显式 id）。graph 参数为全局默认科目。",
        {
            "type": "object",
            "properties": {
                "nodes": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "parent_node_id": {"type": "string"},
                            "canonical_name": {"type": "string"},
                            "node_kind": {"type": "string"},
                            "aliases": {"type": "array", "items": {"type": "string"}},
                            "subject": {"type": "string"},
                            "level": {"type": "string"},
                            "description": {"type": "string"},
                            "tags": {"type": "array", "items": {"type": "string"}},
                            "primary_parent_id": {"type": "string"},
                            "graph": {"type": "string"},
                        },
                        "required": ["canonical_name"],
                    },
                },
                "graph": {"type": "string", "description": "默认科目图谱 slug"},
            },
            "required": ["nodes"],
            "additionalProperties": False,
        },
        graph_tools.tool_batch_create_nodes,
        ui_label="正在批量创建知识要点…",
        allegro_auto_add=True,
    ),
    _fn(
        "graph.update_node",
        "更新已有节点字段。",
        {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "canonical_name": {"type": "string"},
                "node_kind": {"type": "string"},
                "aliases": {"type": "array", "items": {"type": "string"}},
                "subject": {"type": "string"},
                "level": {"type": "string"},
                "description": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "string"}},
                "primary_parent_id": {"type": "string", "description": "思维导图主父节点 ID"},
                "graph": {"type": "string"},
            },
            "required": ["node_id"],
            "additionalProperties": False,
        },
        graph_tools.tool_update_node,
        ui_label="正在更新知识要点…",
    ),
    _fn(
        "graph.delete_node",
        "删除节点及其关联边与绑定（高影响，需确认）。",
        {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "graph": {"type": "string"},
            },
            "required": ["node_id"],
            "additionalProperties": False,
        },
        graph_tools.tool_delete_node,
        risk=ToolRisk.DESTRUCTIVE,
        ui_label="正在删除知识要点…",
        vivace_fast_review=True,
    ),
    _fn(
        "graph.list_relations",
        "列出全部节点关系。graph 参数可筛选特定科目。",
        {
            "type": "object",
            "properties": {"graph": {"type": "string"}},
            "additionalProperties": False,
        },
        graph_tools.tool_list_relations,
        risk=ToolRisk.READ,
        ui_label="正在读取要点关联…",
    ),
    _fn(
        "graph.create_relation",
        "在两点之间创建关系（两点须已存在）。",
        {
            "type": "object",
            "properties": {
                "from_node_id": {"type": "string"},
                "to_node_id": {"type": "string"},
                "relation_type": {"type": "string"},
                "graph": {"type": "string"},
            },
            "required": ["from_node_id", "to_node_id", "relation_type"],
            "additionalProperties": False,
        },
        graph_tools.tool_create_relation,
        ui_label="正在建立要点关联…",
        allegro_auto_add=True,
    ),
    _fn(
        "graph.update_relation",
        "修改已有关系的类型，或颠倒方向。",
        {
            "type": "object",
            "properties": {
                "relation_id": {"type": "string"},
                "relation_type": {"type": "string", "description": "新关系类型，可选"},
                "reverse": {"type": "boolean", "description": "是否颠倒 from/to 方向"},
                "graph": {"type": "string"},
            },
            "required": ["relation_id"],
            "additionalProperties": False,
        },
        graph_tools.tool_update_relation,
        ui_label="正在修改要点关联…",
    ),
    _fn(
        "graph.batch_create_relations",
        "批量创建要点之间的关联（多条边）。",
        {
            "type": "object",
            "properties": {
                "relations": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "from_node_id": {"type": "string"},
                            "to_node_id": {"type": "string"},
                            "relation_type": {"type": "string"},
                            "graph": {"type": "string"},
                        },
                        "required": ["from_node_id", "to_node_id", "relation_type"],
                    },
                },
                "graph": {"type": "string"},
            },
            "required": ["relations"],
            "additionalProperties": False,
        },
        graph_tools.tool_batch_create_relations,
        ui_label="正在批量建立要点关联…",
        allegro_auto_add=True,
    ),
    _fn(
        "graph.delete_relation",
        "按关系标识删除一条关系。",
        {
            "type": "object",
            "properties": {
                "relation_id": {"type": "string"},
                "graph": {"type": "string"},
            },
            "required": ["relation_id"],
            "additionalProperties": False,
        },
        graph_tools.tool_delete_relation,
        risk=ToolRisk.DESTRUCTIVE,
        ui_label="正在删除要点关联…",
        vivace_fast_review=True,
    ),
    _fn(
        "graph.bind_question",
        "将题目与知识点节点绑定。",
        {
            "type": "object",
            "properties": {
                "question_qualified_id": {"type": "string"},
                "node_id": {"type": "string"},
                "graph": {"type": "string", "description": "科目图谱 slug，留空则自动查找"},
            },
            "required": ["question_qualified_id", "node_id"],
            "additionalProperties": False,
        },
        graph_tools.tool_bind_question,
        ui_label="正在把题目挂到知识要点…",
    ),
    _fn(
        "graph.batch_bind_questions",
        "批量将多道题目挂到知识点（按节点分组一次写入，效率高于多次调用 graph.bind_question）。",
        {
            "type": "object",
            "properties": {
                "bindings": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "question_qualified_id": {"type": "string"},
                            "node_id": {"type": "string"},
                        },
                        "required": ["question_qualified_id", "node_id"],
                    },
                },
                "graph": {"type": "string", "description": "科目图谱 slug，留空则自动查找节点归属"},
            },
            "required": ["bindings"],
            "additionalProperties": False,
        },
        graph_tools.tool_batch_bind_questions,
        ui_label="正在批量挂接题目…",
    ),
    _fn(
        "graph.attach_resource",
        "为节点挂载 resource 目录下的资料文件（相对路径）。",
        {
            "type": "object",
            "properties": {
                "node_id": {"type": "string"},
                "relative_path": {"type": "string"},
                "graph": {"type": "string"},
            },
            "required": ["node_id", "relative_path"],
            "additionalProperties": False,
        },
        graph_tools.tool_attach_resource,
        ui_label="正在挂载参考资料…",
        allegro_auto_add=True,
    ),
    _fn(
        "memory.read_index",
        "读取跨会话记忆索引（提示性质，引用前建议再读主题文件核对）。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        memory_tools.tool_read_index,
        risk=ToolRisk.READ,
        ui_label="正在读取长期备忘索引…",
    ),
    _fn(
        "memory.read_topic",
        "读取指定主题记忆文件正文（文件名含 .md）。",
        {
            "type": "object",
            "properties": {"topic": {"type": "string"}},
            "required": ["topic"],
            "additionalProperties": False,
        },
        memory_tools.tool_read_topic,
        risk=ToolRisk.READ,
        ui_label="正在打开备忘主题…",
    ),
    _fn(
        "memory.search",
        "在主题记忆文件中按关键词做简单检索。",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_hits": {"type": "integer"},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
        memory_tools.tool_search,
        risk=ToolRisk.READ,
        ui_label="正在搜索备忘内容…",
    ),
    _fn(
        "agent.set_task_plan",
        "为本轮对话登记多步任务清单，便于跟进进度（仅当前会话有效）。",
        {
            "type": "object",
            "properties": {
                "steps": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string"},
                            "status": {"type": "string"},
                        },
                        "required": ["title"],
                    },
                }
            },
            "required": ["steps"],
            "additionalProperties": False,
        },
        session_tools.tool_set_task_plan,
        risk=ToolRisk.READ,
        ui_label="正在整理任务步骤…",
    ),
    _fn(
        "agent.update_task_step",
        "更新任务清单中某一序号的完成状态（如 pending、doing、done）。",
        {
            "type": "object",
            "properties": {
                "index": {"type": "integer", "description": "从 0 开始的序号"},
                "status": {"type": "string"},
            },
            "required": ["index", "status"],
            "additionalProperties": False,
        },
        session_tools.tool_update_task_step,
        risk=ToolRisk.READ,
        ui_label="正在更新任务进度…",
    ),
    _fn(
        "web.search",
        "联网检索公开网页摘要（用于教学参考；需在环境中配置检索服务密钥）。",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_results": {"type": "integer", "description": "默认 5，最大 10"},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
        web_tools.tool_web_search,
        risk=ToolRisk.READ,
        ui_label="正在搜索公开资料…",
    ),
    _fn(
        "web.fetch",
        "抓取并提取网页正文纯文本（去除导航/广告/样式/脚本，仅保留可读内容）。"
        "适用于教师提供网页链接后分析页面内容，不需要配置 API 密钥。",
        {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "要抓取的网页 URL"},
            },
            "required": ["url"],
            "additionalProperties": False,
        },
        web_tools.tool_web_fetch,
        risk=ToolRisk.READ,
        ui_label="正在提取网页内容…",
    ),
    _fn(
        "agent.run_tool_pipeline",
        "按顺序执行多步工具调用（用于减少往返；若某步需教师确认则会中止并提示分步执行）。",
        {
            "type": "object",
            "properties": {
                "steps": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "tool": {"type": "string"},
                            "arguments": {"type": "object"},
                        },
                        "required": ["tool"],
                    },
                }
            },
            "required": ["steps"],
            "additionalProperties": False,
        },
        pipeline_tools.tool_run_tool_pipeline,
        ui_label="正在执行多步操作…",
    ),
    # Focus switching
    _fn(
        "agent.switch_focus",
        "切换当前聚焦域以获取不同领域的工具能力。可选域：general / bank / graph / analysis / compose / doc_process。",
        {
            "type": "object",
            "properties": {
                "domain": {
                    "type": "string",
                    "enum": ["general", "bank", "graph", "analysis", "compose", "doc_process"],
                    "description": "目标聚焦域",
                },
            },
            "required": ["domain"],
            "additionalProperties": False,
        },
        session_tools.tool_switch_focus,
        risk=ToolRisk.READ,
        ui_label="正在切换工作域…",
    ),
    # Plan Mode
    _fn(
        "agent.enter_plan_mode",
        "进入计划模式：只读探索当前状况并生成结构化执行计划，等待教师审批后再执行。适用于复杂任务。",
        {"type": "object", "properties": {}, "additionalProperties": False},
        session_tools.tool_enter_plan_mode,
        risk=ToolRisk.READ,
        ui_label="正在进入计划模式…",
    ),
    _fn(
        "agent.exit_plan_mode",
        "提交计划并退出计划模式，将计划呈现给教师审批。",
        {
            "type": "object",
            "properties": {
                "plan_file_path": {"type": "string", "description": "计划文件的内容目录相对路径"},
            },
            "additionalProperties": False,
        },
        session_tools.tool_exit_plan_mode,
        risk=ToolRisk.READ,
        ui_label="正在提交计划…",
    ),
    # Skill Activation
    _fn(
        "agent.activate_skill",
        "激活一项技能以获取其详细工作流指引。请先阅读系统提示中的技能目录，匹配后再调用。",
        {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "技能标识名"},
            },
            "required": ["name"],
            "additionalProperties": False,
        },
        session_tools.tool_activate_skill,
        risk=ToolRisk.READ,
        ui_label="正在加载技能指引…",
    ),
    _fn(
        "agent.read_skill_reference",
        "读取技能包内参考文件（如 references/*.md）。path 为相对该技能根目录的路径，例如 references/geometry-2d.md。"
        "内置技能文件不在教师项目目录中，请勿用 file.read 拼仓库源码路径。",
        {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "技能标识名（与 agent.activate_skill 一致）"},
                "path": {"type": "string", "description": "相对技能根目录的路径，如 references/overview.md"},
                "offset": {"type": "integer", "description": "起始行号（0-based），默认 0"},
                "limit": {"type": "integer", "description": "读取行数，默认全部"},
            },
            "required": ["name", "path"],
            "additionalProperties": False,
        },
        session_tools.tool_read_skill_reference,
        risk=ToolRisk.READ,
        ui_label="正在读取技能参考…",
    ),
    # File tools
    _fn(
        "file.read",
        "读取内容目录中的文本文件。支持 offset/limit 按行范围读取大文件。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "内容目录相对路径"},
                "offset": {"type": "integer", "description": "起始行号（0-based），默认 0"},
                "limit": {"type": "integer", "description": "读取行数，默认全部"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        file_tools.tool_file_read,
        risk=ToolRisk.READ,
        ui_label="正在读取文件…",
    ),
    _fn(
        "file.write",
        "创建新文件或整体覆写文件内容（写入操作）。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "内容目录相对路径"},
                "content": {"type": "string", "description": "文件内容"},
            },
            "required": ["path", "content"],
            "additionalProperties": False,
        },
        file_tools.tool_file_write,
        ui_label="正在写入文件…",
    ),
    _fn(
        "file.edit",
        "精确字符串替换编辑：old_string 须在文件中唯一匹配后替换为 new_string。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "内容目录相对路径"},
                "old_string": {"type": "string", "description": "要替换的原文（须在文件中唯一）"},
                "new_string": {"type": "string", "description": "替换后的内容"},
                "replace_all": {"type": "boolean", "description": "是否替换所有匹配项，默认 false"},
            },
            "required": ["path", "old_string", "new_string"],
            "additionalProperties": False,
        },
        file_tools.tool_file_edit,
        ui_label="正在编辑文件…",
    ),
    _fn(
        "file.list",
        "列出目录内容，支持 glob 模式筛选。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "内容目录相对路径，默认根目录"},
                "pattern": {"type": "string", "description": "文件名匹配模式（如 *.yaml），默认 *"},
            },
            "additionalProperties": False,
        },
        file_tools.tool_file_list,
        risk=ToolRisk.READ,
        ui_label="正在列出文件…",
    ),
    _fn(
        "file.search",
        "在文件内容中搜索正则模式，返回匹配行。",
        {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "正则表达式"},
                "path": {"type": "string", "description": "搜索起始路径（文件或目录），默认项目根目录"},
                "ignore_case": {"type": "boolean", "description": "是否忽略大小写"},
                "max_matches": {"type": "integer", "description": "最大匹配数，默认 50"},
            },
            "required": ["pattern"],
            "additionalProperties": False,
        },
        file_tools.tool_file_search,
        risk=ToolRisk.READ,
        ui_label="正在搜索文件内容…",
    ),
    # Document conversion tools
    _fn(
        "doc.convert_to_markdown",
        "将 Word/DOCX 文件转换为 Markdown 格式（需要系统安装 pandoc）。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "DOCX 文件的内容目录相对路径"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        doc_tools.tool_doc_convert_to_markdown,
        risk=ToolRisk.READ,
        ui_label="正在转换文档…",
    ),
    _fn(
        "doc.extract_pdf_text",
        "从 PDF 文件中提取文字内容。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "PDF 文件的内容目录相对路径"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        doc_tools.tool_doc_extract_pdf_text,
        risk=ToolRisk.READ,
        ui_label="正在提取 PDF 文本…",
    ),
    _fn(
        "doc.ocr_image",
        "对图片进行 OCR 文字识别。",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "图片文件的内容目录相对路径"},
                "lang": {"type": "string", "description": "OCR 语言，默认 chi_sim+eng"},
            },
            "required": ["path"],
            "additionalProperties": False,
        },
        doc_tools.tool_doc_ocr_image,
        risk=ToolRisk.READ,
        ui_label="正在识别图片文字…",
    ),
]


def _teacher_schema(
    properties: dict[str, dict[str, Any]] | None = None,
    required: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties or {},
        "required": required or [],
        "additionalProperties": False,
    }


_S = {"type": "string"}
_RAW_TOOLS.extend(
    [
        _fn("teacher.list_capabilities", "列出教师可通过 AI 完成的操作及必须人工确认的安全操作。", _teacher_schema(), teacher_tools.tool_list_capabilities, risk=ToolRisk.READ),
        _fn("teacher.operation_guide", "返回某项高风险人工操作的前置条件、完整步骤和安全提醒。", _teacher_schema({"capability_id": _S}, ["capability_id"]), teacher_tools.tool_operation_guide, risk=ToolRisk.READ),
        _fn("graph.rename_graph", "重命名当前教师自己的知识图谱。", _teacher_schema({"slug": _S, "display_name": _S}, ["slug", "display_name"]), teacher_tools.tool_graph_rename),
        _fn("graph.get_taxonomy", "读取当前教师知识图谱的学科和年级分类。", _teacher_schema(), teacher_tools.tool_graph_get_taxonomy, risk=ToolRisk.READ),
        _fn("graph.set_taxonomy", "配置当前教师知识图谱的学科和年级分类。", _teacher_schema({"subjects": {"type": "array", "items": _S}, "levels": {"type": "array", "items": _S}}), teacher_tools.tool_graph_set_taxonomy),
        _fn("graph.unbind_question", "解除题目与知识点的关联。", _teacher_schema({"question_qualified_id": _S, "node_id": _S, "graph": _S}, ["question_qualified_id", "node_id"]), teacher_tools.tool_graph_unbind_question),
        _fn("graph.detach_resource", "移除知识点上的资源链接，不删除原始资源文件。", _teacher_schema({"link_id": _S, "graph": _S}, ["link_id"]), teacher_tools.tool_graph_detach_resource),
        _fn("bank.delete_item", "删除一道题目。", _teacher_schema({"qualified_id": _S, "storage_path": _S}, ["qualified_id"]), teacher_tools.tool_bank_delete_item, risk=ToolRisk.DESTRUCTIVE),
        _fn("template.list", "列出当前项目中的试卷模板文件。", _teacher_schema(), teacher_tools.tool_template_list, risk=ToolRisk.READ),
        _fn("template.get", "读取一个试卷模板文件。", _teacher_schema({"path": _S}, ["path"]), teacher_tools.tool_template_get, risk=ToolRisk.READ),
        _fn("template.create", "创建试卷模板文件。", _teacher_schema({"path": _S, "content": _S}, ["path", "content"]), teacher_tools.tool_template_create),
        _fn("template.update", "更新试卷模板文件。", _teacher_schema({"path": _S, "content": _S}, ["path", "content"]), teacher_tools.tool_template_update),
        _fn("template.rename", "重命名试卷模板文件。", _teacher_schema({"path": _S, "new_path": _S}, ["path", "new_path"]), teacher_tools.tool_template_rename),
        _fn("template.delete", "删除试卷模板文件。", _teacher_schema({"path": _S}, ["path"]), teacher_tools.tool_template_delete, risk=ToolRisk.DESTRUCTIVE),
        _fn("exam.workspace_list", "列出组卷工作区草稿。", _teacher_schema(), teacher_tools.tool_exam_workspace_list, risk=ToolRisk.READ),
        _fn("exam.workspace_get", "读取一份组卷工作区草稿。", _teacher_schema({"exam_id": _S}, ["exam_id"]), teacher_tools.tool_exam_workspace_get, risk=ToolRisk.READ),
        _fn("exam.workspace_save", "创建或更新组卷工作区草稿。", _teacher_schema({"exam_id": _S, "name": _S, "subject": _S, "export_label": _S, "template_ref": _S, "template_path": _S, "selected_items": {"type": "array", "items": {"type": "object"}}}, ["subject", "export_label", "template_path", "selected_items"]), teacher_tools.tool_exam_workspace_save),
        _fn("exam.workspace_delete", "删除组卷工作区草稿。", _teacher_schema({"exam_id": _S}, ["exam_id"]), teacher_tools.tool_exam_workspace_delete, risk=ToolRisk.DESTRUCTIVE),
        _fn("exam.workspace_copy", "从现有试卷复制一份新的组卷工作区。", _teacher_schema({"source_exam_id": _S, "export_label": _S}, ["source_exam_id", "export_label"]), teacher_tools.tool_exam_workspace_copy),
        _fn("paper.list", "按关键字、学科、状态和交付模式查询当前教师的试卷。", _teacher_schema({"q": _S, "delivery_mode": _S, "status": _S, "subject": _S, "page": {"type": "integer"}, "page_size": {"type": "integer"}}), teacher_tools.tool_paper_list, risk=ToolRisk.READ),
        _fn("paper.analyze", "分析试卷提交、成绩、用时和监考事件；本工具不提供可用于批改的 attempt_id，需要答卷标识时必须再调用 paper.find_submissions。", _teacher_schema({"paper_id": _S}, ["paper_id"]), teacher_tools.tool_paper_analyze, risk=ToolRisk.READ),
        _fn("paper.publications", "列出试卷的发布记录。", _teacher_schema({"paper_id": _S}, ["paper_id"]), teacher_tools.tool_paper_publications, risk=ToolRisk.READ),
        _fn(
            "paper.practice_history",
            "查询班级可用于历史错题卷和专项巩固卷的发布记录与三卷资格。",
            _teacher_schema({"class_id": _S}, ["class_id"]),
            teacher_tools.tool_paper_practice_history,
            risk=ToolRisk.READ,
        ),
        _fn(
            "paper.publish_wrong_question_practice",
            "按每位学生在一条历史发布中的错题，发布个性化历史错题卷。",
            _teacher_schema(
                {
                    "class_id": _S,
                    "source_publication_id": _S,
                    "title": _S,
                    "max_questions_per_student": {"type": "integer", "minimum": 1, "maximum": 100},
                    "start_at": _S,
                    "end_at": _S,
                    "show_results_immediately": {"type": "boolean"},
                    "submission_mode": _S,
                    "max_screen_switches": {"type": "integer", "minimum": 0, "maximum": 999},
                    "time_limit_minutes": {"type": "integer", "minimum": 0, "maximum": 1440},
                },
                ["class_id", "source_publication_id", "title"],
            ),
            teacher_tools.tool_paper_publish_wrong_question_practice,
        ),
        _fn(
            "paper.publish_reinforcement_practice",
            "根据同一班级至少三条历史发布中每位学生的错题或全对题目，调用 AI 生成并发布举一反三专项巩固卷。",
            _teacher_schema(
                {
                    "class_id": _S,
                    "source_publication_ids": {"type": "array", "items": _S, "minItems": 3},
                    "title": _S,
                    "questions_per_student": {"type": "integer", "minimum": 1, "maximum": 20},
                    "start_at": _S,
                    "end_at": _S,
                    "show_results_immediately": {"type": "boolean"},
                    "submission_mode": _S,
                    "max_screen_switches": {"type": "integer", "minimum": 0, "maximum": 999},
                    "time_limit_minutes": {"type": "integer", "minimum": 0, "maximum": 1440},
                },
                ["class_id", "source_publication_ids", "title"],
            ),
            teacher_tools.tool_paper_publish_reinforcement_practice,
        ),
        _fn(
            "paper.find_submissions",
            "按学生、提交状态或批改状态定位答卷。返回的 attempt_id 是后续 AI/人工批改唯一可用的答卷标识；publication_id 只是发布记录标识，绝不能当作 attempt_id。",
            _teacher_schema(
                {
                    "paper_id": _S,
                    "student_query": _S,
                    "status": _S,
                    "grading_status": _S,
                    "limit": {"type": "integer", "minimum": 1, "maximum": 100},
                },
                ["paper_id"],
            ),
            teacher_tools.tool_paper_find_submissions,
            risk=ToolRisk.READ,
        ),
        _fn(
            "paper.ai_grade_pending",
            "为已提交且仍待批改的答卷批量生成 AI 建议；只生成建议，不直接写入最终分。",
            _teacher_schema(
                {
                    "paper_id": _S,
                    "max_attempts": {"type": "integer", "minimum": 1, "maximum": 20},
                    "max_questions_total": {"type": "integer", "minimum": 1, "maximum": 100},
                },
                ["paper_id"],
            ),
            teacher_tools.tool_paper_ai_grade_pending,
        ),
        _fn(
            "paper.offline_upload_guide",
            "说明如何下载并使用线下答卷采集器、支持格式和上传限制。",
            _teacher_schema({}, []),
            teacher_tools.tool_paper_offline_upload_guide,
            risk=ToolRisk.READ,
        ),
        _fn(
            "teacher.student_profile",
            "按可选日期范围读取教师班级内某名学生的完成率、得分、考试行为事件、答题时长和薄弱题目。",
            _teacher_schema(
                {"class_id": _S, "student_id": _S, "student_query": _S, "date_from": _S, "date_to": _S},
                [],
            ),
            teacher_tools.tool_teacher_student_profile,
            risk=ToolRisk.READ,
        ),
        _fn("paper.submissions", "列出试卷答卷及答案。", _teacher_schema({"paper_id": _S}, ["paper_id"]), teacher_tools.tool_paper_submissions, risk=ToolRisk.READ),
        _fn("paper.update_delivery", "修改试卷的线上或线下交付模式。", _teacher_schema({"paper_id": _S, "delivery_mode": _S}, ["paper_id", "delivery_mode"]), teacher_tools.tool_paper_update_delivery),
        _fn("paper.update_publication", "修改考试发布的标题、时间、时长、结果展示和状态。", _teacher_schema({"paper_id": _S, "publication_id": _S, "title": _S, "description": _S, "start_at": _S, "end_at": _S, "time_limit_minutes": {"type": "integer"}, "show_results_immediately": {"type": "boolean"}, "status": _S}, ["paper_id", "publication_id"]), teacher_tools.tool_paper_update_publication),
        _fn("paper.revoke_publication", "撤销考试发布。", _teacher_schema({"paper_id": _S, "publication_id": _S}, ["paper_id", "publication_id"]), teacher_tools.tool_paper_revoke_publication, risk=ToolRisk.DESTRUCTIVE),
        _fn("paper.manual_grade", "人工复核并保存一道主观题得分和反馈。", _teacher_schema({"paper_id": _S, "attempt_id": _S, "question_id": _S, "score": {"type": "number"}, "feedback": _S, "is_correct": {"type": "boolean"}}, ["paper_id", "attempt_id", "question_id", "score"]), teacher_tools.tool_paper_manual_grade),
        _fn("paper.complete_grading", "确认一份答卷已全部批改并向学生发布成绩。", _teacher_schema({"paper_id": _S, "attempt_id": _S}, ["paper_id", "attempt_id"]), teacher_tools.tool_paper_complete_grading),
    ]
)

_CONFIRM_LABELS: dict[str, str] = {
    "paper.ai_grade_pending": "批量生成 AI 预批改建议",
    "paper.complete_grading": "确认完成批改并向学生发布成绩",
    "paper.publish_wrong_question_practice": "发布个性化历史错题卷",
    "paper.publish_reinforcement_practice": "调用 AI 生成并发布专项巩固卷",
    "exam.export_paper": "导出试卷文件",
    "exam.validate_paper": "校验选题与卷面结构并写入临时配置",
    "graph.delete_node": "删除知识要点及其关联",
    "graph.delete_relation": "删除要点之间的关联",
    "graph.create_node": "新建知识要点",
    "graph.update_node": "修改知识要点",
    "graph.create_relation": "新建要点关联",
    "graph.update_relation": "修改要点关联",
    "graph.batch_create_nodes": "批量新建知识要点",
    "graph.batch_create_relations": "批量新建要点关联",
    "graph.batch_bind_questions": "批量将题目挂接到知识要点",
    "graph.bind_question": "将题目挂接到知识要点",
    "graph.attach_resource": "为要点挂载资料",
    "graph.create_graph": "新建科目图谱",
    "graph.delete_graph": "删除科目图谱",
    "bank.update_item": "修改题库中的题目内容",
    "bank.create_item": "在个人题库中新建题目",
    "analysis.save_script": "保存分析脚本",
    "analysis.run_script": "运行分析脚本",
    "analysis.run_builtin": "运行内置学情分析",
    "analysis.create_remediation_draft": "生成补练卷草稿",
    "agent.run_subtask": "分步深入分析子任务",
    "agent.run_tool_pipeline": "按序执行多步工具",
    "file.write": "写入内容目录文件",
    "file.edit": "编辑内容目录文件",
}


def _apply_confirm_labels(tools: list[RegisteredTool]) -> list[RegisteredTool]:
    return [replace(t, action_label=t.action_label or _CONFIRM_LABELS.get(t.name)) for t in tools]


TOOLS = _apply_confirm_labels(_RAW_TOOLS)

SUBTASK_TOOL_NAME = "agent.run_subtask"


def subtask_tool_schema() -> RegisteredTool:
    return RegisteredTool(
        name=SUBTASK_TOOL_NAME,
        description=(
            "启动子任务深度分析：在隔离上下文中多步调用工具，仅将精简结论返回主对话。"
            "用于复杂诊断、脚本调试或综合报告素材收集。"
        ),
        parameters_schema={
            "type": "object",
            "properties": {
                "objective": {"type": "string", "description": "子任务目标与成功标准"},
                "allowed_tool_prefixes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "允许的工具名前缀，如 analysis.、memory.；留空表示不额外限制",
                },
            },
            "required": ["objective"],
            "additionalProperties": False,
        },
        handler=lambda ctx, args: ToolResult(status="failed", error_message="handled in orchestrator"),
        risk=ToolRisk.WRITE,
        ui_label="正在分步深入分析…",
        action_label=_CONFIRM_LABELS.get(SUBTASK_TOOL_NAME),
    )
