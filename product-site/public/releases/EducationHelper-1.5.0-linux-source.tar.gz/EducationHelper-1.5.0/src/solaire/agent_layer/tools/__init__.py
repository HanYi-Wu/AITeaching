"""Tool handlers for AgentLayer."""
