import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { AgentProvider } from "../../contexts/AgentContext";
import { SettingsWorkspace } from "../SettingsWorkspace";

const mocks = vi.hoisted(() => ({
  apiAgentLlmSettingsGet: vi.fn(),
  apiAgentSafetyModeGet: vi.fn(),
  apiAgentSafetyModePut: vi.fn(),
  getAccountProfile: vi.fn(),
  updateAccountCredentials: vi.fn(),
}));

vi.mock("../../platform/auth", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../platform/auth")>();
  return { ...actual, getAccountProfile: mocks.getAccountProfile, updateAccountCredentials: mocks.updateAccountCredentials };
});

vi.mock("../../api/client", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../api/client")>();
  return {
    ...actual,
    apiAgentLlmSettingsGet: mocks.apiAgentLlmSettingsGet,
    apiAgentSafetyModeGet: mocks.apiAgentSafetyModeGet,
    apiAgentSafetyModePut: mocks.apiAgentSafetyModePut,
  };
});

vi.mock("../../components/settings/AgentModelSettingsForm", () => ({
  AgentModelSettingsForm: () => <div data-testid="model-settings-form" />,
}));

vi.mock("../../components/ExtensionsPanel", () => ({
  ExtensionsPanel: () => <div data-testid="extensions-panel" />,
}));

vi.mock("../LogWorkspace", () => ({
  LogWorkspace: () => <div data-testid="settings-log" />,
}));

function renderSettings(userRole: "admin" | "teacher") {
  return render(
    <AgentProvider>
      <SettingsWorkspace userRole={userRole} onError={vi.fn()} />
    </AgentProvider>,
  );
}

describe("SettingsWorkspace role gating", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.apiAgentLlmSettingsGet.mockResolvedValue({
      persist_available: true,
      persist_scope: "project",
      provider: "openai",
      provider_options: [{ id: "openai" }],
      main_model: "gpt-4.1",
      fast_model: "gpt-4.1-mini",
      base_url: "",
      llm_configured: true,
      api_key_masked: "********abcd",
      has_project_api_key_override: true,
      reasoning_effort: "high",
    });
    mocks.apiAgentSafetyModeGet.mockResolvedValue({
      persist_available: true,
      persist_scope: "project",
      mode: "allegro",
      options: [],
    });
    mocks.getAccountProfile.mockResolvedValue({ profile: { id: "t1", role: "teacher", username: "teacher", display_name: "教师", status: "active" } });
    mocks.updateAccountCredentials.mockResolvedValue({ user: { id: "t1", role: "teacher", username: "teacher", display_name: "教师", status: "active" } });
  });

  it("hides model and extension configuration for teachers and keeps logs inside settings", async () => {
    renderSettings("teacher");

    expect(await screen.findByTestId("settings-log")).toBeInTheDocument();
    expect(screen.queryByTestId("extensions-panel")).not.toBeInTheDocument();
    expect(screen.queryByTestId("model-settings-form")).not.toBeInTheDocument();
    await waitFor(() => expect(mocks.apiAgentLlmSettingsGet).not.toHaveBeenCalled());
  });

  it("keeps model configuration available to admins", async () => {
    renderSettings("admin");

    expect(await screen.findByTestId("model-settings-form")).toBeInTheDocument();
    expect(screen.getByTestId("settings-log")).toBeInTheDocument();
    expect(mocks.apiAgentLlmSettingsGet).toHaveBeenCalled();
  });

  it("lets a teacher change their own password", async () => {
    renderSettings("teacher");
    await userEvent.type(await screen.findByLabelText("当前密码"), "oldpass1");
    await userEvent.type(screen.getByLabelText("新密码"), "newpass2");
    await userEvent.type(screen.getByLabelText("确认新密码"), "newpass2");
    await userEvent.click(screen.getByRole("button", { name: "修改密码" }));
    await waitFor(() => expect(mocks.updateAccountCredentials).toHaveBeenCalledWith({ current_password: "oldpass1", new_password: "newpass2" }));
  });
});
