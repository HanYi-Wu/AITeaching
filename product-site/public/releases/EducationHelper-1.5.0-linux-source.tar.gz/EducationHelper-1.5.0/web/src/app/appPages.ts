export type AppPage =
  | "compose"
  | "papers"
  | "students"
  | "bank"
  | "template"
  | "graph"
  | "analysis"
  | "help"
  | "log"
  | "admin"
  | "school"
  | "student"
  | "settings";
